// ignore_for_file: must_be_immutable
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets';
// Welcome Screen images
  static String imgImage27 = '$imagePath/img.png';
  static String imageNotFound = 'assets/image_not_found.png';
}
